/*
* StringIntersection
* by Stoica Benjamin
* on 2023-01-15
*
* 
*/

using System;

namespace Leonding.POSE.StringIntersection
{
	class Profram
	{
		public static void Main(string[]args)
		{
			//input of sentences
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
			
			string finalSentence = "";
			
			//searchin for intersections
			for(int i = 0; i < firstSentence.Length; i++)
			{
				for(int j = 0; j < secondSentence.Length; j++) 
				{
					if(firstSentence[i] == secondSentence[j])
					{
						finalSentence+=secondSentence[j];
					}
				}
			}
			
			//ouput of intersections
			Console.WriteLine($"The intersection of both sentences is: {finalSentence}");
		}
	}
}