using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
		
			int lengthOfFirstSentence = firstSentence.Length;
			int lengthOfSecondSentence = secondSentence.Length;
			
			Console.Write("The intersection of both sentence is: ");
			
			string intersection = "";
			
			for(int i = 0; i < lengthOfFirstSentence; i++)
			{
				char currChar = firstSentence[i];
		
				for(int j = 0; j < lengthOfSecondSentence; j++)
				{
					bool isFound = false;
					
					if(currChar == secondSentence[j])
					{
						for(int k = 0; k < intersection.Length; k++)
						{
							if(currChar == intersection[k])
							{
								isFound = true;
							}
						}
						
						if(!isFound)
						{
							intersection += currChar;
							
							Console.Write($"{currChar}");
						}
					}
				}	
			}
		}
	}
}