/*
* This program reads 2 user given sentences and tells the user which letters are in each.
* by Richard Eichinger
* on 17.01.2023
*/
using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main (string[]args)
		{
			Console.Write("Please enter the first sentence:");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence:");
			string secondSentence = Console.ReadLine();
			
			string intersection = "";
			
			for(int i = 0; i < firstSentence.Length; i++) 
			{
				char currentCharFirstSentence = firstSentence[i];
				
				for(int j = 0; j < secondSentence.Length; j++) 
				{
					char currentCharSecondSentence = secondSentence[j];
					
					if (currentCharFirstSentence == currentCharSecondSentence)
					{
						intersection += currentCharFirstSentence;
					}
				}
			}
			
			Console.WriteLine($"The intersection of both sentences is: {intersection}");
		}
	}
}