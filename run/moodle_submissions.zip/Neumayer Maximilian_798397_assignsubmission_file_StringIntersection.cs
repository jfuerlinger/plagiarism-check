//////////////////////////////////////////////////////////////////////////
//
//	Neumayer Maximilian
//	12.01.2023
//	1BHIF
//		 This program lets you enter 2 sentences and then
//		 it shows you the intersection of the 2 sentences,
//		 but it shows you every letter only one time.
//
//////////////////////////////////////////////////////////////////////////
using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main(string[] args)
		{
			//here you enter your 2 sentences
			Console.Write("Please enter the first sentence: ");
			string firstUserSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondUserSentence = Console.ReadLine();
			
			//seeing how long the sentences are
			int firstSentenceLength = firstUserSentence.Length;
			int secondSentenceLength = secondUserSentence.Length;
			
			string intersection = "";
			
			//going through every letter
			for(int i = 0; i < firstSentenceLength; i++)
			{
				for(int j = 0; j < secondSentenceLength; j++)
				{
					char currFirstSentenceChar = firstUserSentence[i];
					char currSecondSentenceChar = secondUserSentence[j];
					
					//checking if the letters from the 2 sentences are identical
					if(currFirstSentenceChar == currSecondSentenceChar)
					{			
						//declaring a boolean to not have letters get put out 2 times
						bool isLetterFound = false;
						
						//going through until no letter in the intersection equals the letter which should get added
						for(int k = 0; k < intersection.Length && !isLetterFound; k++)
						{
							//setting the boolen to true if the current char equals one in the intersection
							if(intersection[k] == currFirstSentenceChar)
							{
								isLetterFound = true;
							}
						}
						
						//if the letter wasn't found in the intersection, add it to it
						if(!isLetterFound)
						{
							intersection += currFirstSentenceChar;
						}
					}
				}
			}
			
			Console.Write($"The intersection of both sentences is: {intersection}");
		}
	}
}