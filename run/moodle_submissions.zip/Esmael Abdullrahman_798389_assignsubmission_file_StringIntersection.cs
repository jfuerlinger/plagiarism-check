using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			int firstSentenceLength = firstSentence.Length;
			
			Console.Write("Please enter the second sentence: ");			
			string secondSentence = Console.ReadLine();
			int secondSentenceLength = secondSentence.Length;
			
			string intersection = "";
			
			
			for(int i = 0; i < firstSentenceLength; i++)
			{
				char currCharOfFirstSentence = firstSentence[i];
				
				for(int j = 0; j < secondSentenceLength; j++)
				{
					char currCharOfSecondSentence = secondSentence[j];
					bool isFound = false;
					
					if(currCharOfFirstSentence == currCharOfSecondSentence)
					{
						for(int k = 0; k < resultCommonFeatures.Length; k++)
						{
							char currCharToSeeIfEqual = resultCommonFeatures[k];
						
							if(currCharToSeeIfEqual == currCharOfFirstSentence)
							{
								isFound = true;
							}
						}
						
						if(!isFound)
						{
							intersection += currCharOfSecondSentence;
						}
					}
				}
			}
			
			Console.WriteLine($"The intersection of both sentences is: {resultCommonFeatures}");
		}
	}
}