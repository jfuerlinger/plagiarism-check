using System;

class Program 
{
	public static void Main()
	{
		Console.Write("Please enter the first sentence: ");
		string firstUserInput = Console.ReadLine();
		
		Console.Write("Please enter the second sentence: ");
		string secondUserInput = Console.ReadLine();
		
		int lengthFromFirstSentence = firstUserInput.Length;
		int lengthFromSecondSentence = secondUserInput.Length;
		
		string dupChars = "";
		bool isInDupChars = false;
		
		for(int i = 0; i < lengthFromFirstSentence; i++)
		{
			for(int j = 0; j < lengthFromSecondSentence; j++)
			{
				if(firstUserInput[i] == secondUserInput[j])
				{
					
					for(int k = 0; k < dupChars.Length && isInDupChars == false; k++)
					{
						if(firstUserInput[i] == dupChars[k])
						{
							isInDupChars = true;
						}
					}
												
					if(isInDupChars == false)
					{
						dupChars += firstUserInput[i];
					}
					else
					{
						isInDupChars = false;
					}
				}
			}
		}
		
		Console.WriteLine($"The intersection of both sentences is: {dupChars}");
	}
}