using System;

namespace Leonding.Pose.StringIntersection 
{
	class Program 
	{
		public static void Main(string[] args) 
		{
			Console.Write("Please enter the first sentence: ");
			string sentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSEntence = Console.ReadLine();
			
			Console.Write("The intersection of both sentences is: ");
			string intersectionOfSentences = "";
			
			for(int i = 0; i < sentence.Length; i++)
			{
				
				char currentChar = sentence[i];
				
				for(int j = 0; j < secondSEntence.Length; j++)
				{
					
					bool isFound = false;
					
					if(currentChar == secondSEntence[j])
					{
						for(int f = 0; f < intersectionOfSentences.Length; f++)
						{
							
							if(currentChar == intersectionOfSentences[f])
							{
								isFound = true;
							}
						}
						
						if(!isFound)
						{
							intersectionOfSentences += currentChar;
							Console.Write($"{currentChar}");
						}
						
					}
				}
				
			}
			
		}
	}
}