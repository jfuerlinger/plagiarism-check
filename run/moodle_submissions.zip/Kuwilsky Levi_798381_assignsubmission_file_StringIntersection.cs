/*
 Program noch nicht fertig, kleiner fehler vorhanden
*/

using System;

namespace Leonding.Pose.StringIntersection
{
	public class program
	{
		public static void Main(string[] args)
		{
			//Ask user to enter the first sentence.
			Console.Write("Please enter the first sentence: ");
			string firstEnteredSentence = Console.ReadLine();
			
			//
			int lengthOfFirstEnteredSentence = firstEnteredSentence.Length;
			
			//Ask user to enter  the second sentence.
			Console.Write("Please enter the second sentence: ");
			string secondEnteredSentence = Console.ReadLine();
			
			//
			int lengthOfSecondEnteredSentence = secondEnteredSentence.Length;
			
			//
			string intersection = "";
			
			int lengthOfIntersection = intersection.Length;
			
			for(int i = 0; i < lengthOfFirstEnteredSentence; i++)
			{
				char currCharOfFirstSentence = firstEnteredSentence[i];
				
				for(int j = 0; j < lengthOfSecondEnteredSentence; j++)
				{
					char currCharOfSecondSentence = secondEnteredSentence[j];
					
					if(currCharOfFirstSentence == currCharOfSecondSentence)
					{
						for(int k = 0; k < lengthOfIntersection; k++)
						{
							char currCharOfIntersection = intersection[k];
							
							if(currCharOfIntersection != currCharOfSecondSentence)
							{
								intersection += currCharOfSecondSentence;
							}
						}
					}
				}
			}
			
			//Print the intersection of both sentences.
			Console.WriteLine($"The intersection of both sentences is: {intersection}");
		}
	}
}