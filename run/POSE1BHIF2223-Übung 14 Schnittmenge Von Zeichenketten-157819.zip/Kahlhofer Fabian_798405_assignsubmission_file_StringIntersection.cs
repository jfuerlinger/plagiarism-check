using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main(string[] args )
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
			
			string output = "";
			
			for (int i = 0; i < firstSentence.Length; i++)
			{
				for (int j = 0; j < secondSentence.Length; j++)
				{
					if (firstSentence[i] == secondSentence[j])
					{
						bool doesCharExistInOutput = false;
						
						for (int n = 0; n < output.Length; n++)
						{
							if (output[n] == firstSentence[i])
							{
								doesCharExistInOutput = true;
							}
						}
						
						if (!doesCharExistInOutput)
						{
							output += firstSentence[i];
						}
					}
				}
			}
			
			Console.WriteLine($"The intersection of both sentences is: {output}");
		}
	}
}