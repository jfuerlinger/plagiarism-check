﻿using System;

namespace Leonding.Pose.StringIntersection
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Please enter the first sentence: ");
            string firstSentence = Console.ReadLine();

            Console.Write("Please enter the second sentence: ");
            string secondSentence = Console.ReadLine();

            string sameLetters = string.Empty;
            bool doesExist = false;

            for(int i = 0; i < firstSentence.Length; i++)
            {
                for(int j = 0; j < secondSentence.Length; j++)
                {
                    if(firstSentence[i] == secondSentence[j])
                    {
                        for(int k = 0; k < sameLetters.Length ; k++)
                        {
                            if (sameLetters[k] == secondSentence[j])
                            {
                                doesExist = true;
                            }
                        }

                        if(!doesExist)
                        {
                            sameLetters += firstSentence[i];
                        }    
                        doesExist = false;
                    }
                }
            }
            Console.WriteLine($"The intersection of both sentences is: {sameLetters}");
        }
    }
}