using System;

namespace Leonding.Pose.StringIntersection 
{
	class Program 
	{
		public static void Main(string[] args) 
		{
			Console.Write("\nPlease enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
			
			Console.Write("The intersection of both sentences is: ");
			
			string charaktersFound = "";
			
			for (int i = 0; i < firstSentence.Length; i++ ) 
			{
				char currChar = firstSentence[i];
				
				for (int j = 0; j < secondSentence.Length; j++ ) 
				{		
					bool isFound = false;
			
					if(currChar == secondSentence[j]) 
					{
						for (int k = 0; k < charaktersFound.Length; k++) 
						{
							if (currChar == charaktersFound[k]) 
							{
								isFound = true;
							}
						}
						if(!isFound) 
						{
							charaktersFound+= currChar;
							
							Console.Write($"{currChar}");
						}
					}
				}
			}
		}
	}
}