using System;

class Program
{
	public static void Main()
	{
		bool isFirstIntersection = true;
		bool hasFoundIntersection = false;

		string intersectingChars = "";
		Console.Write("Please enter the first sentence:");
		string firstSentence = Console.ReadLine();
		
		Console.Write("Please enter the second sentence: ");
		string secondSentence = Console.ReadLine();
		
		for (int i = 0; i < firstSentence.Length; i++)
		{
			for (int j = 0; j < secondSentence.Length; j++)
			{
                hasFoundIntersection = false;

                if (firstSentence[i] == secondSentence[j] && isFirstIntersection)
				{
                    intersectingChars += secondSentence[j];
					isFirstIntersection = false;
				}
				else if (firstSentence[i] == secondSentence[j])
				{
                    for (int k = 0; k < intersectingChars.Length && !hasFoundIntersection; k++)
                    {

                        if (intersectingChars[k] == secondSentence[j])
                        {
							hasFoundIntersection = true;
                        }
                    }

					if (!hasFoundIntersection)
					{
						intersectingChars += secondSentence[j];
					}
                }
				
			}
		}
		
		Console.WriteLine($"The intersection of both sentences is: {intersectingChars}");
	}
}