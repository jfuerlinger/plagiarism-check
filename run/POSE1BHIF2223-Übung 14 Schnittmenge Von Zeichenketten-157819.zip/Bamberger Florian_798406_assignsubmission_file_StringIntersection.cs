using System;

namespace Leonding.Pose.StringIntersection
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
			
			string currentIntersection = "";
			
			
			//Goes through the goes through the first sentence
			for(int i = 0; i < firstSentence.Length; i++)
			{
				//Goes through the second sentence for very letter of the first sentence.
				for(int j = 0; j < secondSentence.Length; j++)
				{
					bool isAlreadyInIntersection = false;
					
					//Checks if the letter at i is the same as the letter at j.
					if(firstSentence[i] == secondSentence[j])
					{
						//Checks if the letter was already in the intersecting part once.
						for(int k = 0; k < currentIntersection.Length && !isAlreadyInIntersection; k++)
						{
							if(firstSentence[i] == currentIntersection[k])
							{
								isAlreadyInIntersection = true;
							}
						}
						
						//Adds the letter to the intersecting part.
						if(!isAlreadyInIntersection)
						{
							currentIntersection += firstSentence[i];
						}	
					}
				}
			}
			
			Console.WriteLine($"The intersection of both sentences is:{currentIntersection}");
		}
	}
}