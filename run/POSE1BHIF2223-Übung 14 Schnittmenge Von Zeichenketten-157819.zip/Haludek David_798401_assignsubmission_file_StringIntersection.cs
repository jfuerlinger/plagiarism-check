using System;

namespace Leonding.POSE.StringIntersection
{

	class Program
	{
		static void Main(string[] args)
		{
			Console.Write("Please enter the first sentence:: ");
			string firstUserSentence = Console.ReadLine();

			Console.Write("Please enter the second sentence: ");
			string secoundUserSentence = Console.ReadLine();

			Console.Write("The intersection of both sentences is: ");

			for (int i = 0; i < firstUserSentence.Length; i++)
			{
				for (int j = 0; j < secoundUserSentence.Length; j++)
				{
					if (firstUserSentence[i] == secoundUserSentence[j])
					{
						bool alreadyPrinted = false;
						for (int k = 0; k < i; k++)
						{
							if (firstUserSentence[k] == firstUserSentence[i])
							{
								alreadyPrinted = true;                      
							}
						}
						if (!alreadyPrinted)
						{
							Console.Write(firstUserSentence[i] + " ");
						}
					}
				}
			}
		}
	}
}
