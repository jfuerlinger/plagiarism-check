using System;

namespace StringIntersection
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();
			
			//initialize an intersection variable
			string intersection = "";
			
			for(int i = 0; i < firstSentence.Length; i++)
			{
				for(int j = 0; j < secondSentence.Length; j++)
				{
					bool isInIntersection = false;
					
					//search for intersections
					if(firstSentence[i] == secondSentence[j])
					{
						for(int k = 0; k < intersection.Length && !isInIntersection; k++)
						{
							if(intersection[k] == firstSentence[i])
							{
								isInIntersection = true;
							}
						}
						
						//add the character to the intersection if it isn't there already
						if(!isInIntersection)
						{
							intersection += firstSentence[i];
						}
					}
				}
			}
			
			Console.WriteLine($"The intersection of both sentences is: {intersection}");
		}
	}
}