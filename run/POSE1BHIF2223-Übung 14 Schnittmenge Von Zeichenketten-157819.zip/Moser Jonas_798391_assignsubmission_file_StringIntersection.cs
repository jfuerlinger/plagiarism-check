using System;

namespace Leonding.Pose.String
{
    class Program
    {
        public static void Main(string[] args)
        {


            Console.Write("Please enter the first sentence: ");
            string firstSentence = Console.ReadLine();
            Console.Write("Please enter the second sentence: ");
            string secondSentence = Console.ReadLine();

            string usedLetters = string.Empty;
            string newString = string.Empty;
            

            for (int i = 0; i < firstSentence.Length; i++)
            {
                char currChar = firstSentence[i];
                for (int j = 0; j < secondSentence.Length; j++)
                {
                    char charForCompare = secondSentence[j];
                    if (charForCompare == currChar)
                    {
                        bool isUed = false;
                        for (int k = 0; k < usedLetters.Length; k++)
                        {
                            char usedChar = usedLetters[k];
                            if (usedChar == currChar)
                            {
                                isUed = true;
                            }
                        }
                        if(!isUed)
                        {
                            newString += currChar;
                            usedLetters += currChar;
                        }
                        
                    }
                }
            }

            Console.WriteLine($"The intersection of both sentences is: {newString}");
            Console.ReadKey();

        }

    }
}