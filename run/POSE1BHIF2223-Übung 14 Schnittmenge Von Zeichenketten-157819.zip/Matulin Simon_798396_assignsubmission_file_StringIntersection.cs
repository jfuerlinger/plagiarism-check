using System;

namespace StringIntersection
{
    class Program
    {
        public static void Main(string[] args)
        {
            //First sentnce input
            Console.Write("Please enter the first sentence: ");
            string firstSentence = Console.ReadLine();

            //Second sentence input
            Console.Write("Please enter the second sentence: ");
            string secondSentence = Console.ReadLine();

            string intersection = "";

            //going through the first sentence chars
            for(int i = 0;i < firstSentence.Length;i++)
            {
                char firstSentenceChar = firstSentence[i];

                //going through the second sentence chars
                for(int j = 0;j < secondSentence.Length;j++)
                {
                    char secondSentenceChar = secondSentence[j];

                    //compare first and second char
                    if(firstSentenceChar == secondSentenceChar)
                    {
                        bool isTwice = false;

                        //compare intersection with the intersectiontext           
                        for(int k = 0;k  < intersection.Length && !isTwice;k++)
                        {
                            char intersectionChar = intersection[k];

                            if(intersectionChar == firstSentenceChar)
                            {
                                isTwice = true;
                            }
                        }

                        if(!isTwice)
                        {
                            intersection += firstSentenceChar;
                        }
                    }
                }
            }

            //intersection output
            Console.WriteLine($"The intersection of both sentences is: {intersection}");
        }
    }
}