/*
* StringIntersection
* by Alexander Coroi
* on 2023-01-12
*
* This program outputs various the intersection from two sentences.
*/

using System;

namespace Leonding.Pose.StringIntersection 
{
	class Program 
	{
		public static void Main(string[] args) 
		{
			Console.Write("Please enter the first sentence: ");
			string firstSentence = Console.ReadLine();
			
			Console.Write("Please enter the second sentence: ");
			string secondSentence = Console.ReadLine();

			string finalSentence = "";			
			string alreadyFoundChars = "";

			for (int i = 0; i < firstSentence.Length; i++)
			{
				for (int j = 0; j < secondSentence.Length; j++)
				{	
					bool hasFound = false;
					
					if(firstSentence[i] == secondSentence[j]) 
					{
						for	(int k = 0; k < alreadyFoundChars.Length && !hasFound; k++) 
						{
							if(firstSentence[i] == alreadyFoundChars[k]) 
							{
								hasFound = true;
							}
						}
						
						if(!hasFound)
						{
							alreadyFoundChars += firstSentence[i];
							finalSentence += firstSentence[i];
						}
					}					
				}
			}
			Console.WriteLine($"The intersection of both sentences is: {finalSentence}");
		}
	}
}